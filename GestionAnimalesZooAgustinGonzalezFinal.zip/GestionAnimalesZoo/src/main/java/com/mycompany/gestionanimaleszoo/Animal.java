package com.mycompany.gestionanimaleszoo;
import java.io.Serializable;

public class Animal implements Comparable<Animal>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;
    
    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }
    
    public int getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public String getEspecie() {
        return especie;
    }
    
    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    
    @Override
    public int compareTo(Animal o) {
        return Integer.compare(this.id, o.id);
    }

    public String toCSV() {
        return id + "," + nombre + "," + especie + "," + alimentacion;
    }

    public static Animal fromCSV(String csv) {
        String[] parts = csv.split(",");
        return new Animal(
            Integer.parseInt(parts[0]),
            parts[1],
            parts[2],
            TipoAlimentacion.valueOf(parts[3])
        );
    }

    @Override
    public String toString() {
        return "Animal{" + "id=" + id + ", nombre='" + nombre + '\'' + ", especie='" + especie + '\'' + ", alimentacion=" + alimentacion + '}';
    }

}
