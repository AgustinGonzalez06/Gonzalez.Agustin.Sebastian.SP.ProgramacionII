
package com.mycompany.gestionanimaleszoo;


public interface CSVSerializable {
    String toCSV();
}