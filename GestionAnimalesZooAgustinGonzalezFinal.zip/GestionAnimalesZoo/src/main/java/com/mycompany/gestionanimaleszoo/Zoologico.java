package com.mycompany.gestionanimaleszoo;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Zoologico<T extends CSVSerializable & Comparable<T>> {
    private List<T> inventario = new ArrayList<>();

    // Método para agregar un elemento al inventario
    public void agregar(T elemento) {
        inventario.add(elemento);
    }

    // Método para obtener un elemento por índice
    public T obtener(int indice) {
        return inventario.get(indice);
    }

    // Método para eliminar un elemento por índice
    public void eliminar(int indice) {
        inventario.remove(indice);
    }

    // Método para filtrar elementos según un criterio
    public List<T> filtrar(Predicate<T> criterio) {
        return inventario.stream().filter(criterio).collect(Collectors.toList());
    }

    // Método para ordenar de manera natural (por id)
    public void ordenar() {
        Collections.sort(inventario);
    }

    // Método para ordenar con un Comparator
    public void ordenar(Comparator<T> comparador) {
        inventario.sort(comparador);
    }

    // Método para guardar el inventario en un archivo CSV
    public void guardarEnCSV(String ruta) throws IOException {
        File archivo = new File(ruta);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
            for (T elemento : inventario) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }
    }

    // Método para cargar el inventario desde un archivo CSV
    public void cargarDesdeCSV(String ruta, FuncionCreadora<T> creador) throws IOException {
        File archivo = new File(ruta);
        if (!archivo.exists()) {
            throw new FileNotFoundException("El archivo no existe: " + ruta);
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            inventario = reader.lines()
                .map(creador::crear)
                .collect(Collectors.toList());
        }
    }

    // Método para guardar el inventario en un archivo binario
    public void guardarEnArchivo(String ruta) throws IOException {
        File archivo = new File(ruta);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(inventario);
        }
    }

    // Método para cargar el inventario desde un archivo binario
    @SuppressWarnings("unchecked")
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
    File archivo = new File(ruta);

    // Crear archivo vacío si no existe
    if (!archivo.exists()) {
        archivo.createNewFile(); // Crea el archivo vacío
        // Inicializar un inventario vacío ya que no hay datos en el archivo
        inventario = new ArrayList<>();
        return;
    }

    // Leer el archivo si existe y contiene datos
    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
        inventario = (List<T>) ois.readObject();
    } catch (EOFException e) {
        // Manejar archivo vacío sin datos
        inventario = new ArrayList<>();
    }
}

    // Método para aplicar una acción a cada elemento
    public void paraCadaElemento(Consumer<T> accion) {
        inventario.forEach(accion);
    }
}

@FunctionalInterface
interface FuncionCreadora<T> {
    T crear(String linea);
}
